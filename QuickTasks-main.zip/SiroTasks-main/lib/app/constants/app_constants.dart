class AppConstants {
  static const appTitle = "Siro's Task";
  static const loginTitle = "Login";
  static const homeTitle = "Home";
  static const taskTitle = "To Do";
}
