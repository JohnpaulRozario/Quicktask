/// Event Object for api calls
class EventObject {
  int id;
  String response;

  EventObject({required this.id, required this.response});
}
